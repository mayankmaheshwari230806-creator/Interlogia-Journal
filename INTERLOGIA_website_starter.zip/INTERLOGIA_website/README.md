# INTERLOGIA website starter

A responsive, static website starter for **INTERLOGIA — Journal of Economics, Philosophy and Interdisciplinary Studies**.

## Included
- Responsive homepage and mobile navigation
- About, research areas, Call for Papers, author guidelines, editorial information, FAQ and contact sections
- Clearly marked placeholders for unconfirmed details
- Accessible navigation and reduced-motion support
- No build step or paid framework required

## Preview locally
1. Extract the ZIP file.
2. Open `index.html` in a web browser.

For best results, use a local static server or deploy the folder to a static hosting provider. Google Fonts require an internet connection; fallback fonts are included.

## Before launch
Replace or confirm all placeholder information:
- Journal email and official contact details
- Submission deadline and manuscript requirements
- Peer-review process and publication ethics policies
- Editorial board members (with consent and institutional approval)
- Institutional affiliation and permission to use college/club branding
- Publication schedule, acceptance criteria and any publication charges (if applicable)
- ISSN only after officially assigned

## Submission functionality
This starter does **not** collect or store manuscript files. Before inviting actual submissions, add a secure submission method (for example, an approved form/file-upload service or journal management platform) and publish a privacy notice. Do not advertise submissions as open until the process and deadline are confirmed.

## Suggested launch checklist
1. Confirm title availability and institutional approval.
2. Confirm the editor/publisher and editorial board.
3. Finalise author guidelines and review policy.
4. Set up a dedicated journal email and secure submission route.
5. Add the deadline, manuscript template and privacy notice.
6. Test on mobile and desktop, then publish.
